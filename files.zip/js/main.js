document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');
    app.innerHTML = `
        <h1>Welcome to Geist</h1>
        <button id="start-onboarding">Get Started</button>
    `;

    document.getElementById('start-onboarding').addEventListener('click', () => {
        loadOnboarding();
    });
});

function loadOnboarding() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <h2>Let's get to know you</h2>
        <p>What's your name?</p>
        <input type="text" id="user-name" placeholder="Enter your name">
        <button id="submit-name">Next</button>
    `;

    document.getElementById('submit-name').addEventListener('click', () => {
        const userName = document.getElementById('user-name').value;
        localStorage.setItem('userName', userName);
        loadDashboard();
    });
}

function loadDashboard() {
    const userName = localStorage.getItem('userName');
    const app = document.getElementById('app');
    app.innerHTML = `
        <h1>Welcome, ${userName}</h1>
        <p>This is your daily dashboard.</p>
        <!-- Additional dashboard components will be added here -->
    `;
}